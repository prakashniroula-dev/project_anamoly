#pragma once
#include <string>
#include <vector>
#include <SFML/System/Vector2.hpp>

struct DialogueLine {
    std::string speaker;
    std::string text;
    std::string condition;   // optional, e.g. "playerHasItem(key)"
    std::string action;      // optional, e.g. "giveQuest(id)"
    std::vector<DialogueLine> options; // for branching
};

struct NPCType {
    std::string id;                  // unique type key, e.g. "detective_explainer"
    std::string characterKey;        // sprite key from Characters
    std::string behaviorType;        // "idle", "patrol", "follow", "scripted"
    std::vector<DialogueLine> dialogue;
    std::string scriptName;          // optional, for special logic (e.g., "detective")
    std::vector<sf::Vector2f> waypoints;
    float talkRadius = 100.f;
    bool autoStartDialogue = false;
    float autoStartDelay = 0.f;
};