#pragma once
#include "ui_screen.hpp"
#include <entities/npc.hpp>
#include <SFML/Graphics/Text.hpp>

class DialogScreen : public UIScreen {
public:
    DialogScreen(NPC* npc);
    void onEnter() override;
    void onExit() override;
    bool handleEvent(const sf::Event& event, sf::RenderWindow& window) override;
    void update(float dt) override;
    void draw(sf::RenderWindow& window) override;
    bool blocksGameUpdate() const override { return true; }

private:
    NPC* npc;
    std::vector<DialogueLine> lines;
    size_t currentLineIndex = 0;
    sf::Text speakerText;
    sf::Text dialogueText;
    sf::Font font; 
    sf::RectangleShape background;

    void advanceDialogue();
};