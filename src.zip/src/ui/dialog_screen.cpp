#include "dialog_screen.hpp"
#include <ui/ui_manager.hpp>
#include <debug/logs.hpp>

DialogScreen::DialogScreen(NPC* npc) : npc(npc), speakerText(font), dialogueText(font) {
    if (!npc) {
        Log::error << "DialogueScreen created with null NPC" << std::endl;
        return;
    }
    lines = npc->getType().dialogue;
    // Load font from a global resource (you should pass it or get from a global)
    // We'll assume you have a global font, or load it here.
    // For simplicity, we'll use a dummy initialization; you need to set actual font.
    speakerText.setCharacterSize(28);
    dialogueText.setCharacterSize(20);
    background.setFillColor(sf::Color(0,0,0,200));
    background.setSize({400,200});
    speakerText.setStyle(sf::Text::Bold);
    dialogueText.setStyle(sf::Text::Regular);
    font = UIManager::get().getFont(); // Assuming UIManager has a method to get a shared font
}

void DialogScreen::onEnter() {
    currentLineIndex = 0;
    if (!lines.empty()) {
        speakerText.setString(lines[currentLineIndex].speaker);
        dialogueText.setString(lines[currentLineIndex].text);
    } else {
        // No dialogue lines – close immediately
        UIManager::get().popScreen();
    }
}

void DialogScreen::advanceDialogue() {
    if (currentLineIndex + 1 < lines.size()) {
        currentLineIndex++;
        speakerText.setString(lines[currentLineIndex].speaker);
        dialogueText.setString(lines[currentLineIndex].text);
        // You could handle conditions/actions here
    } else {
        // End of dialogue
        if (npc) {
            npc->setTalked(true);
            // If there is a talkEnd callback, it will be invoked inside NPC::talk? Actually we need to call it.
            // Better: NPC sets a callback that we call here.
        }
        UIManager::get().popScreen();
    }
}

bool DialogScreen::handleEvent(const sf::Event& event, sf::RenderWindow& window) {
    // Any key or mouse click advances dialogue
    if (event.is<sf::Event::KeyPressed>() || event.is<sf::Event::MouseButtonPressed>()) {
        advanceDialogue();
        return true;
    }
    return false;
}

void DialogScreen::update(float dt) {
    // nothing
}

void DialogScreen::draw(sf::RenderWindow& window) {
    // Ensure we are drawing in the default (pixel‑perfect) view
    sf::View defaultView = window.getDefaultView();
    window.setView(defaultView);

    sf::Vector2f winSize = defaultView.getSize();
    float boxWidth = 500.f;
    float boxHeight = 120.f;

    // Round background position and size to whole pixels
    float bgX = std::round((winSize.x - boxWidth) / 2.f);
    float bgY = std::round(winSize.y - boxHeight);
    background.setPosition({bgX, bgY});
    background.setSize({std::round(boxWidth), std::round(boxHeight)});
    window.draw(background);

    // Round text positions
    sf::Vector2f speakerPos = {std::round(bgX + 20.f), std::round(bgY + 15.f)};
    speakerText.setPosition(speakerPos);

    sf::Vector2f dialoguePos = {std::round(bgX + 20.f), std::round(bgY + 60.f)};
    dialogueText.setPosition(dialoguePos);

    window.draw(speakerText);
    window.draw(dialogueText);
}

void DialogScreen::onExit() {
    // Optional cleanup, e.g., remove references to NPC
}